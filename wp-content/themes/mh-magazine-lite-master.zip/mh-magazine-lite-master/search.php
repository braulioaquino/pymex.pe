<?php get_header(); ?>
<div class="mh-wrapper mh-clearfix">
	<div id="main-content" class="mh-loop mh-content" role="main">
<script>
  (function() {
    var cx = 'partner-pub-7512798297333598:9845999173';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  })();
</script>
<gcse:searchresults-only queryParameterName="s"></gcse:searchresults-only>
	</div>
	<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
